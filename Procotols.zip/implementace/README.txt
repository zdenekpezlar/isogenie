Nejprve se musi nainstalovat potrebny package:
sage --pip3 install bottle

Implementaci spustime prikazem:
sage form.py

V prohlizeci otevreme http://localhost:port (spravny port nam rekne form.py pri spusteni)

